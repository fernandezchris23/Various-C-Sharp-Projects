﻿namespace Assign2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.saveLocBttn = new System.Windows.Forms.Button();
            this.saveSizeBttn = new System.Windows.Forms.Button();
            this.resetSettBttn = new System.Windows.Forms.Button();
            this.addNameBttn = new System.Windows.Forms.Button();
            this.nameBox = new System.Windows.Forms.TextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.saveLocBttn);
            this.groupBox1.Controls.Add(this.saveSizeBttn);
            this.groupBox1.Controls.Add(this.resetSettBttn);
            this.groupBox1.Controls.Add(this.addNameBttn);
            this.groupBox1.Controls.Add(this.nameBox);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(625, 114);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // saveLocBttn
            // 
            this.saveLocBttn.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.saveLocBttn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveLocBttn.Location = new System.Drawing.Point(515, 82);
            this.saveLocBttn.Name = "saveLocBttn";
            this.saveLocBttn.Size = new System.Drawing.Size(98, 23);
            this.saveLocBttn.TabIndex = 8;
            this.saveLocBttn.Text = "Save Location";
            this.saveLocBttn.UseVisualStyleBackColor = true;
            // 
            // saveSizeBttn
            // 
            this.saveSizeBttn.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.saveSizeBttn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveSizeBttn.Location = new System.Drawing.Point(12, 82);
            this.saveSizeBttn.Name = "saveSizeBttn";
            this.saveSizeBttn.Size = new System.Drawing.Size(83, 23);
            this.saveSizeBttn.TabIndex = 7;
            this.saveSizeBttn.Text = "Save Size";
            this.saveSizeBttn.UseVisualStyleBackColor = true;
            // 
            // resetSettBttn
            // 
            this.resetSettBttn.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.resetSettBttn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resetSettBttn.Location = new System.Drawing.Point(280, 82);
            this.resetSettBttn.Name = "resetSettBttn";
            this.resetSettBttn.Size = new System.Drawing.Size(102, 23);
            this.resetSettBttn.TabIndex = 6;
            this.resetSettBttn.Text = "Reset Settings";
            this.resetSettBttn.UseVisualStyleBackColor = true;
            // 
            // addNameBttn
            // 
            this.addNameBttn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.addNameBttn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addNameBttn.Location = new System.Drawing.Point(423, 28);
            this.addNameBttn.Name = "addNameBttn";
            this.addNameBttn.Size = new System.Drawing.Size(83, 23);
            this.addNameBttn.TabIndex = 5;
            this.addNameBttn.Text = "Add Name";
            this.addNameBttn.UseVisualStyleBackColor = true;
            this.addNameBttn.Click += new System.EventHandler(this.addNameBttn_Click_1);
            // 
            // nameBox
            // 
            this.nameBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.nameBox.Location = new System.Drawing.Point(68, 28);
            this.nameBox.Name = "nameBox";
            this.nameBox.Size = new System.Drawing.Size(336, 20);
            this.nameBox.TabIndex = 0;
            this.nameBox.TextChanged += new System.EventHandler(this.nameBox_TextChanged);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(625, 428);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox nameBox;
        private System.Windows.Forms.Button saveLocBttn;
        private System.Windows.Forms.Button saveSizeBttn;
        private System.Windows.Forms.Button resetSettBttn;
        private System.Windows.Forms.Button addNameBttn;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}

