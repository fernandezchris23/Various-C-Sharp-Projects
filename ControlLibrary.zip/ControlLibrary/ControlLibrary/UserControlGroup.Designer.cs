﻿namespace ControlLibrary
{
    partial class teamCtrl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupName = new System.Windows.Forms.Label();
            this.names = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // groupName
            // 
            this.groupName.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupName.Font = new System.Drawing.Font("Bell MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupName.ForeColor = System.Drawing.Color.Navy;
            this.groupName.Location = new System.Drawing.Point(0, 0);
            this.groupName.Name = "groupName";
            this.groupName.Size = new System.Drawing.Size(669, 23);
            this.groupName.TabIndex = 0;
            this.groupName.Text = "Team We\'re OK";
            // 
            // names
            // 
            this.names.Dock = System.Windows.Forms.DockStyle.Fill;
            this.names.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.names.Location = new System.Drawing.Point(0, 23);
            this.names.Name = "names";
            this.names.Size = new System.Drawing.Size(669, 146);
            this.names.TabIndex = 1;
            this.names.Text = "Christopher Fernandez      Alejandro Barnolan      Ian Cuvalay\nWalter Elwell      Alvaro Orozco      " +
    "Kayla Ortiz      Vanesa Perez";
            // 
            // teamCtrl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.Controls.Add(this.names);
            this.Controls.Add(this.groupName);
            this.Name = "teamCtrl";
            this.Size = new System.Drawing.Size(669, 169);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label groupName;
        private System.Windows.Forms.Label names;
    }
}
