﻿namespace ControlLibrary
{
    partial class BaseDialogForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.userControlCourse1 = new ControlLibrary.UserControlCourse();
            this.teamCtrl1 = new ControlLibrary.teamCtrl();
            this.panel1 = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // userControlCourse1
            // 
            this.userControlCourse1.BackColor = System.Drawing.Color.Transparent;
            this.userControlCourse1.Dock = System.Windows.Forms.DockStyle.Top;
            this.userControlCourse1.Location = new System.Drawing.Point(0, 0);
            this.userControlCourse1.Name = "userControlCourse1";
            this.userControlCourse1.Size = new System.Drawing.Size(800, 77);
            this.userControlCourse1.TabIndex = 1;
            // 
            // teamCtrl1
            // 
            this.teamCtrl1.BackColor = System.Drawing.Color.LightSteelBlue;
            this.teamCtrl1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.teamCtrl1.Location = new System.Drawing.Point(0, 372);
            this.teamCtrl1.Name = "teamCtrl1";
            this.teamCtrl1.Size = new System.Drawing.Size(800, 78);
            this.teamCtrl1.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 77);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 295);
            this.panel1.TabIndex = 2;
            // 
            // BaseDialogForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.userControlCourse1);
            this.Controls.Add(this.teamCtrl1);
            this.Name = "BaseDialogForm";
            this.Text = "BaseDialogForm";
            this.ResumeLayout(false);

        }

        #endregion

        private teamCtrl teamCtrl1;
        private UserControlCourse userControlCourse1;
        private System.Windows.Forms.Panel panel1;
    }
}